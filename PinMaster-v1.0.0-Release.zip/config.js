var CONFIG = {
    GUMROAD: {
        // Base64 Encoded ID (Standard Obfuscation)
        // Decodes to: AkHQgUKYqLnHhtR_hpxGdQ==
        PRODUCT_ID: 'QWtIUWdVS1lxTG5IaHRSX2hweEdkUQ==',
        VERIFY_ENDPOINT: 'https://api.gumroad.com/v2/licenses/verify'
    },
    LIMITS: {
        FREE_PIN_LIMIT: 50,
        REVERIFY_HOURS: 72
    },
    STORAGE_KEYS: {
        PRO_STATUS: 'pro_status',
        LICENSE_KEY: 'license_key',
        LAST_VERIFIED: 'last_verified_at'
    }
};
